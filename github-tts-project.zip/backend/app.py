
from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import tempfile
from ibm_watson import TextToSpeechV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

load_dotenv()

IBM_API_KEY = os.getenv("IBM_API_KEY")
IBM_URL = os.getenv("IBM_URL")

authenticator = IAMAuthenticator(IBM_API_KEY)
tts = TextToSpeechV1(authenticator=authenticator)
tts.set_service_url(IBM_URL)

app = Flask(__name__)
CORS(app)

@app.route("/synthesize", methods=["POST"])
def synthesize():
    data = request.json
    text = data.get("text")
    if not text:
        return jsonify({"error": "No text provided"}), 400

    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as audio_file:
        response = tts.synthesize(
            text,
            voice='en-US_AllisonV3Voice',
            accept='audio/mp3'
        ).get_result()

        audio_file.write(response.content)
        audio_file_path = audio_file.name

    return send_file(audio_file_path, mimetype='audio/mp3', as_attachment=False)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
