"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Upload, Play, Pause, Download, Mic, Volume2, FileAudio } from "lucide-react"

const emotions = [
  { value: "neutral", label: "Neutral" },
  { value: "happy", label: "Happy" },
  { value: "sad", label: "Sad" },
  { value: "angry", label: "Angry" },
  { value: "excited", label: "Excited" },
  { value: "calm", label: "Calm" },
]

export default function TextToSpeechApp() {
  const [text, setText] = useState("")
  const [selectedVoice, setSelectedVoice] = useState("")
  const [selectedEmotion, setSelectedEmotion] = useState("neutral")
  const [emotionIntensity, setEmotionIntensity] = useState([50])
  const [isPlaying, setIsPlaying] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [audioUrl, setAudioUrl] = useState("")
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const audioRef = useRef<HTMLAudioElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [voiceModels, setVoiceModels] = useState([
    { value: "en-US_AllisonV3Voice", label: "Allison (US English)", type: "preset" },
    { value: "en-US_MichaelV3Voice", label: "Michael (US English)", type: "preset" },
    { value: "en-US_LisaV3Voice", label: "Lisa (US English)", type: "preset" },
    { value: "en-US_KevinV3Voice", label: "Kevin (US English)", type: "preset" },
    { value: "en-US_EmmaV3Voice", label: "Emma (US English)", type: "preset" },
    { value: "en-GB_KateV3Voice", label: "Kate (UK English)", type: "preset" },
    { value: "en-GB_JamesV3Voice", label: "James (UK English)", type: "preset" },
  ])

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type.startsWith("audio/")) {
      setUploadedFile(file)

      // Add uploaded voice to voice models
      const uploadedVoiceModel = {
        value: `uploaded_voice_${Date.now()}`,
        label: `${file.name.replace(/\.[^/.]+$/, "")} (Uploaded Voice)`,
        type: "uploaded" as const,
        file: file,
      }

      // Remove any existing uploaded voice and add the new one
      setVoiceModels((prev) => [...prev.filter((voice) => voice.type !== "uploaded"), uploadedVoiceModel])

      // Automatically select the uploaded voice
      setSelectedVoice(uploadedVoiceModel.value)
    }
  }

  const handleGenerateSpeech = async () => {
    if (!text.trim() || !selectedVoice) return

    setIsGenerating(true)

    const selectedVoiceModel = voiceModels.find((voice) => voice.value === selectedVoice)

    if (selectedVoiceModel?.type === "uploaded") {
      // Handle uploaded voice generation
      // TODO: Integrate with voice cloning API
      // const formData = new FormData()
      // formData.append('audio', selectedVoiceModel.file)
      // formData.append('text', text)
      // formData.append('emotion', selectedEmotion)
      // formData.append('intensity', emotionIntensity[0].toString())
      //
      // const response = await fetch('YOUR_VOICE_CLONING_ENDPOINT', {
      //   method: 'POST',
      //   body: formData
      // })

      // Simulate API call for uploaded voice
      setTimeout(() => {
        setAudioUrl("/placeholder-cloned-audio.mp3")
        setIsGenerating(false)
      }, 3000)
    } else {
      // Handle preset voice generation with IBM Watson
      // TODO: Integrate with IBM Watson API
      // const response = await fetch('https://api.us-south.text-to-speech.watson.cloud.ibm.com/v1/synthesize', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //     'Authorization': 'Bearer YOUR_API_KEY'
      //   },
      //   body: JSON.stringify({
      //     text: text,
      //     voice: selectedVoice,
      //     accept: 'audio/mp3'
      //   })
      // })

      // Simulate API call for preset voice
      setTimeout(() => {
        setAudioUrl("/placeholder-audio.mp3")
        setIsGenerating(false)
      }, 2000)
    }
  }

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleDownload = () => {
    if (audioUrl) {
      const link = document.createElement("a")
      link.href = audioUrl
      link.download = "generated-speech.mp3"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 pt-8">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-blue-600 rounded-2xl">
              <Volume2 className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              VoiceForge
            </h1>
          </div>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            Transform your text into natural, expressive speech with advanced AI voice synthesis
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Text Input Section */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="rounded-3xl shadow-lg border-0 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-xl">
                  <FileAudio className="w-5 h-5 text-blue-600" />
                  Text Input
                </CardTitle>
                <CardDescription>Enter the text you want to convert to speech</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Type or paste your text here... The more expressive your writing, the better the speech will sound!"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="min-h-[200px] text-lg leading-relaxed border-0 bg-slate-50/50 rounded-2xl resize-none focus:ring-2 focus:ring-blue-500/20 transition-all duration-300"
                />
                <div className="flex justify-between items-center mt-4 text-sm text-slate-500">
                  <span>{text.length} characters</span>
                  <span>{text.split(" ").filter((word) => word.length > 0).length} words</span>
                </div>
              </CardContent>
            </Card>

            {/* Voice Cloning Upload */}
            <Card className="rounded-3xl shadow-lg border-0 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Mic className="w-5 h-5 text-purple-600" />
                  Voice Cloning
                </CardTitle>
                <CardDescription>Upload an audio sample to create a custom voice model</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div
                  className="border-2 border-dashed border-slate-300 rounded-2xl p-8 text-center transition-all duration-300 hover:border-purple-400 hover:bg-purple-50/50 cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 mb-2">
                    {uploadedFile ? uploadedFile.name : "Click to upload audio file"}
                  </p>
                  <p className="text-sm text-slate-500">Supports MP3, WAV, M4A files up to 10MB</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="audio/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>

                {/* Show integration status when file is uploaded */}
                {uploadedFile && (
                  <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 animate-in slide-in-from-top-4 duration-500">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse"></div>
                      <div>
                        <p className="text-purple-800 font-medium">Voice Successfully Uploaded!</p>
                        <p className="text-purple-600 text-sm">
                          Your voice is now available in the voice models dropdown above.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Controls Section */}
          <div className="space-y-6">
            {/* Voice Selection */}
            <Card className="rounded-3xl shadow-lg border-0 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Voice Model</CardTitle>
                <CardDescription>Choose your preferred voice</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                  <SelectTrigger className="rounded-xl border-0 bg-slate-50/50 h-12">
                    <SelectValue placeholder="Select a voice model" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {voiceModels.map((voice) => (
                      <SelectItem key={voice.value} value={voice.value} className="rounded-lg">
                        <div className="flex items-center gap-2">
                          {voice.type === "uploaded" && <div className="w-2 h-2 bg-purple-500 rounded-full"></div>}
                          {voice.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Emotion Controls */}
            <Card className="rounded-3xl shadow-lg border-0 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Emotion & Tone</CardTitle>
                <CardDescription>Adjust the emotional expression</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Emotion</Label>
                  <Select value={selectedEmotion} onValueChange={setSelectedEmotion}>
                    <SelectTrigger className="rounded-xl border-0 bg-slate-50/50 h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      {emotions.map((emotion) => (
                        <SelectItem key={emotion.value} value={emotion.value} className="rounded-lg">
                          {emotion.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label>Intensity: {emotionIntensity[0]}%</Label>
                  <Slider
                    value={emotionIntensity}
                    onValueChange={setEmotionIntensity}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Generate Button */}
            <Button
              onClick={handleGenerateSpeech}
              disabled={!text.trim() || !selectedVoice || isGenerating}
              className="w-full h-14 rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold text-lg shadow-lg transition-all duration-300 hover:shadow-xl disabled:opacity-50"
            >
              {isGenerating ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating...
                </div>
              ) : (
                "Generate Speech"
              )}
            </Button>
          </div>
        </div>

        {/* Audio Player Section */}
        {audioUrl && (
          <Card className="rounded-3xl shadow-lg border-0 bg-white/80 backdrop-blur-sm transition-all duration-300 hover:shadow-xl">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-xl">
                <Play className="w-5 h-5 text-green-600" />
                Generated Audio
              </CardTitle>
              <CardDescription>Your text has been converted to speech</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Button
                  onClick={togglePlayPause}
                  size="lg"
                  className="rounded-2xl bg-green-600 hover:bg-green-700 text-white shadow-lg transition-all duration-300"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </Button>

                <div className="flex-1 bg-slate-100 rounded-2xl h-12 flex items-center px-4">
                  <div className="flex-1 bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full">
                    <div className="w-1/3 bg-white h-full rounded-full shadow-sm"></div>
                  </div>
                </div>

                <Button
                  onClick={handleDownload}
                  variant="outline"
                  size="lg"
                  className="rounded-2xl border-2 hover:bg-slate-50 transition-all duration-300 bg-transparent"
                >
                  <Download className="w-5 h-5" />
                </Button>
              </div>

              <audio ref={audioRef} src={audioUrl} onEnded={() => setIsPlaying(false)} className="hidden" />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
